from enum import Enum


class Endian(Enum):
    LITTLE = 0
    BIG = 1
